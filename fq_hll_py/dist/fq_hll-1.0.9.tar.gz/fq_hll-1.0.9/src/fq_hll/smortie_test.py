# from fq_hll import Autocorrector

from Autocorrector import Autocorrector

if __name__ == "__main__":
    dictionary = ["smortie", "klofr", "cloffer", "pou", "poumortie", "ugli_ferg", "lil_shet", "mamamia"]
    custom_ac = Autocorrector(dictionary)

    queries = ["clover", "klover", "klovr", "klove", "poo", "shit", "smart"]

    print(queries)
    print("========")
    print(custom_ac.autocorrect(queries, "None", True, False))
    print("========")
    print(custom_ac.top3(queries, "None", True, False))
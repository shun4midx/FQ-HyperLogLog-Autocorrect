from .Hasher import str_to_u64
from .HyperLogLog import SketchConfig, HyperLogLog
from .Autocorrector import Autocorrector
from .compare import compare_files
from .compare3 import compare3_files